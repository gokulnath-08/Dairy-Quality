<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    die("Unauthorized Access");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="logo.png">
    <title>QR Code Generator</title>
    <nav class="navbar">
        <div class="logo">
            <img src="logo.png" alt="Logo">
            <span style="color: white; font-size: 20px; font-weight: bold;">Dairy Quality Checker</span>
        </div>
        <button class="menu-toggle" onclick="toggleMenu()">☰</button>
        <ul>
            <li><a id="homeLink" href="#">Home</a></li>
            <li><a href="adminscanner.php">Scanner</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </nav>

    <script>
        const baseURL = window.location.origin;
        document.getElementById("homeLink").href = baseURL;
        function toggleMenu() {
            let menu = document.querySelector('.navbar ul');
            menu.classList.toggle('active');

            if (menu.classList.contains('active')) {
                menu.style.display = "flex";
            } else {
                menu.style.display = "none";
            }
        }
    </script>

    <style>
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #000;
        }

        .navbar .logo {
            display: flex;
            align-items: center;
        }

        .navbar .logo img {
            height: 30px;
            margin-right: 8px;
        }

        .navbar ul {
            list-style: none;
            display: flex;
            gap: 12px;
        }

        .navbar ul li a {
            text-decoration: none;
            color: white;
            font-size: 19px;
            padding: 6px 10px;
            border-radius: 4px;
            transition: background 0.3s;
        }

        .navbar ul li a:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .menu-toggle {
            display: none;
            font-size: 22px;
            background: none;
            border: none;
            color: white;
            cursor: pointer;
            width: 40px;
            height: 40px;
            padding: 5px;
        }

        @media (max-width: 768px) {
            .navbar ul {
                display: none;
                flex-direction: column;
                background: rgba(0, 0, 0, 0.9);
                position: absolute;
                top: 50px;
                right: 10px;
                text-align: left;
                padding: 10px;
                border-radius: 6px;
                box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.3);
                width: 150px;
            }

            .navbar ul.active {
                display: flex;
            }

            .menu-toggle {
                display: block;
            }
        }
    </style>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #3498db, #2ecc71);
            animation: backgroundAnimation 6s infinite alternate;
        }

        @keyframes backgroundAnimation {
            0% {
                background: linear-gradient(135deg, #3498db, #2ecc71);
            }

            100% {
                background: linear-gradient(135deg, #2ecc71, #3498db);
            }
        }

        .container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
            width: 350px;
            transition: 0.3s;
        }

        .container:hover {
            transform: scale(1.02);
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 22px;
            font-weight: bold;
        }

        input[type="text"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 2px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
            transition: 0.3s ease;
        }

        input[type="text"]:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 8px rgba(0, 123, 255, 0.6);
        }

        input[type="submit"] {
            background: #28a745;
            color: white;
            padding: 12px;
            border: none;
            width: 100%;
            border-radius: 6px;
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            transition: all 0.3s ease;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        input[type="submit"]:hover {
            background: #218838;
            transform: scale(1.05);
        }

        .loader-container {
            display: none;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            margin-top: 20px;
        }

        .spinner {
            width: 40px;
            height: 40px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid #28a745;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        .hidden {
            display: none;
        }

        .message {
            margin-top: 15px;
            padding: 10px;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            text-align: center;
        }

        .error {
            background-color: white;
            color: red;
        }

        .success {
            background-color: white;
            color: green;
        }
    </style>
    <script>
        function showLoader() {
            document.getElementById("loader-container").style.display = "flex";
            document.getElementById("submit-btn").disabled = true;
        }
    </script>
</head>

<body>
    <div class="container">
        <h2>Generate QR Code</h2>
        <form action="process.php" method="post" onsubmit="showLoader()">
            <input type="text" name="test_no" id="test_no" required placeholder="Enter Sample Number to Generate">
            <br>

            <input type="checkbox" name="protect_qr" id="protect_qr" value="1">
            <label for="protect_qr">Protect QR Code</label>
            <br><br>

            <input type="submit" id="submit-btn" value="Generate QR Code">
            <div id="loader-container" class="loader-container">
                <div class="spinner"></div>
                <p class="success">Generating QR Code...</p>
            </div>
        </form>

        <?php
        if (isset($_GET['error'])) {
            echo "<p class='message error'>" . htmlspecialchars($_GET['error']) . "</p>";
        }
        if (isset($_GET['success'])) {
            echo "<p class='message success'>QR Code Generated Successfully!</p>";
        }
        ?>
    </div>
</body>

</html>