<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('db_connect.php');

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    die("Unauthorized access!");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : null;
} elseif (isset($_SESSION['id'])) {
    $id = $_SESSION['id'];
} else {
    die("Invalid request! ID is required.");
}

$_SESSION['id'] = $id;
$tableName = "milkdata" . $id;

$checkTable = $conn->query("SHOW TABLES LIKE '$tableName'");
if ($checkTable->num_rows === 0) {
    die("Error: Table '$tableName' does not exist!");
}

if (isset($_POST['truncate'])) {
    $conn->query("TRUNCATE TABLE $tableName");
    header("Location: detail.php");
    exit();
}

$limit = 10;
$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
$offset = ($page - 1) * $limit;

$sql = "SELECT FORMAT(ph_level / 100, 2) AS ph_level, milk_quality, last_scan_time
        FROM $tableName
        ORDER BY last_scan_time DESC
        LIMIT $limit OFFSET $offset";

$result = $conn->query($sql);

$countQuery = "SELECT COUNT(*) AS total FROM $tableName";
$countResult = $conn->query($countQuery);
$totalRows = $countResult->fetch_assoc()['total'];
$totalPages = ceil($totalRows / $limit);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Milk Data</title>
    <link rel="icon" type="image/png" href="logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background: linear-gradient(135deg, #2E8B57, #1E90FF);
            color: white;
            text-align: center;
        }

        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 20px;
            background-color: #000;
        }

        .navbar .logo {
            display: flex;
            align-items: center;
        }

        .navbar .logo img {
            height: 30px;
            margin-right: 8px;
        }

        .navbar ul {
            list-style: none;
            display: flex;
            gap: 12px;
        }

        .navbar ul li a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            padding: 6px 12px;
            border-radius: 4px;
            transition: background 0.3s;
        }

        .navbar ul li a:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .header-buttons {
            position: absolute;
            top: 60px;
            left: 0;
            width: 100%;
            display: flex;
            justify-content: space-between;
            padding: 10px 20px;
        }

        .truncate-button,
        .reload-button {
            background: transparent;
            border: none;
            cursor: pointer;
        }

        .truncate-button i,
        .reload-button i {
            font-size: 24px;
            color: white;
            transition: color 0.3s;
        }

        .truncate-button:hover i {
            color: red;
        }

        .reload-button:hover i {
            color: yellow;
        }

        .table-container {
            width: 90%;
            max-width: 800px;
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            margin-top: 80px;
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 18px;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: center;
            color: black;
        }

        th {
            background: #28a745;
            color: white;
        }

        tr:nth-child(even) {
            background: #f2f2f2;
        }

        tr:hover {
            background: #ddd;
        }

        td[colspan="3"] {
            font-size: 18px;
            padding: 20px;
            background: #f8d7da;
            color: #721c24;
            font-weight: bold;
        }

        label {
            font-size: 20px;
            font-weight: bold;
            color: white;
            margin-bottom: 20px;
            display: block;
            color: black;
            scale: 1.2;

        }
    </style>
</head>

<body>

    <nav class="navbar">
        <div class="logo">
            <img src="logo.png" alt="Logo">
            <span style="color: white; font-size: 20px; font-weight: bold;">Dairy Quality Checker</span>
        </div>
        <button class="menu-toggle" onclick="toggleMenu()">☰</button>
        <ul>
            <li><a id="homeLink" href="#">Home</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </nav>
    <script>
        const baseURL = window.location.origin;
        document.getElementById("homeLink").href = baseURL;

        function toggleMenu() {
            let menu = document.querySelector('.navbar ul');
            menu.classList.toggle('active');

            if (menu.classList.contains('active')) {
                menu.style.display = "flex";
            } else {
                menu.style.display = "none";
            }
        }
    </script>
    <style>
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #000;
            box-sizing: border-box;
            flex-wrap: wrap;
        }

        .navbar ul {
            list-style: none;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .navbar ul li {
            white-space: nowrap;
        }

        .navbar ul li a {
            text-decoration: none;
            color: white;
            font-size: 19px;
            padding: 6px 10px;
            border-radius: 4px;
            transition: background 0.3s;
        }

        .navbar ul li a:hover {
            background: rgba(255, 255, 255, 0.3);
        }



        .navbar .logo {
            display: flex;
            align-items: center;
        }

        .navbar .logo img {
            height: 30px;
            margin-right: 8px;
        }

        .navbar ul {
            list-style: none;
            display: flex;
            gap: 12px;
        }

        .navbar ul li a {
            text-decoration: none;
            color: white;
            font-size: 19px;
            padding: 6px 10px;
            border-radius: 4px;
            transition: background 0.3s;
        }

        .navbar ul li a:hover {
            background: rgba(255, 255, 255, 0.3);
        }


        .menu-toggle {
            display: none;
            font-size: 22px;
            background: none;
            border: none;
            color: white;
            cursor: pointer;
            width: 40px;
            height: 40px;
            padding: 5px;
        }

        @media (max-width: 768px) {
            .navbar ul {
                display: none;
                flex-direction: column;
                background: rgba(0, 0, 0, 0.9);
                position: absolute;
                top: 50px;
                right: 10px;
                text-align: left;
                padding: 10px;
                border-radius: 6px;
                box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.3);
                width: 150px;
            }

            .navbar ul.active {
                display: flex;
            }

            .menu-toggle {
                display: block;
            }
        }
    </style>

    <div class="header-buttons">
        <form method="post" onsubmit="return confirm('Are you sure you want to delete all records?');">
            <input type="hidden" name="truncate" value="1">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <button type="submit" class="truncate-button">
                <i class="fas fa-trash"></i>
            </button>
        </form>

        <button class="reload-button" onclick="location.reload();">
            <i class="fas fa-sync-alt"></i>
        </button>
    </div>

    <div class="table-container">
        <label>DAIRY QUALITY (SAMPLE NO: <?php echo $id ?>)</label>
        <table>
            <tr>
                <th>pH Level</th>
                <th>Milk Quality</th>
                <th>Last Scan Date & Time</th>
            </tr>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?= $row['ph_level'] ?></td>
                            <td><?= $row['milk_quality'] ?></td>
                            <td><?= $row['last_scan_time'] ?></td>
                        </tr>
                    <?php } ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">No data found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</body>

</html>

<?php $conn->close(); ?>