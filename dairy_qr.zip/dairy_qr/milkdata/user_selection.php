<?php
session_start();
include('db_connect.php');

$error_message = "";
$id = $_GET['id'] ?? '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['user_type']) && $_POST['user_type'] === 'admin') {
        $input_username = $_POST['username'] ?? '';
        $input_password = $_POST['password'] ?? '';

        $stmt = $conn->prepare("SELECT password FROM admin_users WHERE username = ?");
        $stmt->bind_param("s", $input_username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($db_password);
            $stmt->fetch();
            if ($input_password === $db_password) {
                $_SESSION['admin'] = true;
                echo "<form id='postForm' action='./detail.php' method='POST'>
                        <input type='hidden' name='id' value='" . htmlspecialchars($id) . "'>
                      </form>
                      <script>document.getElementById('postForm').submit();</script>";
                exit();
            } else {
                $error_message = "Invalid username or password!";
            }
        } else {
            $error_message = "Invalid username or password!";
        }
        $stmt->close();
    } else {
        header("Location: ./redirect.php?id=" . urlencode($id));
        exit();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select User Type</title>
    <link rel="icon" type="image/jpeg" href="icon.jpeg">
    <nav class="navbar">
    <div class="logo">
        <img src="logo.png" alt="Logo">
        <span style="color: white; font-size: 20px; font-weight: bold;">Dairy Quality Checker</span>
    </div>
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>
    <ul>
            <li><a id="homeLink" href="#">Home</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
</nav>

<script>
    const baseURL = window.location.origin;
    document.getElementById("homeLink").href = baseURL;
    function toggleMenu() {
        let menu = document.querySelector('.navbar ul');
        menu.classList.toggle('active');
        
        if (menu.classList.contains('active')) {
            menu.style.display = "flex";
        } else {
            menu.style.display = "none";
        }
    }
</script>

<style>
    .navbar {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        z-index: 1000;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 20px;
        background-color: #000;
    }

    .navbar .logo {
        display: flex;
        align-items: center;
    }

    .navbar .logo img {
        height: 30px;
        margin-right: 8px;
    }

    .navbar ul {
        list-style: none;
        display: flex;
        gap: 12px;
    }

    .navbar ul li a {
        text-decoration: none;
        color: white;
        font-size: 19px;
        padding: 6px 10px;
        border-radius: 4px;
        transition: background 0.3s;
    }

    .navbar ul li a:hover {
        background: rgba(255, 255, 255, 0.3);
    }

    .menu-toggle {
        display: none;
        font-size: 22px;
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        width: 40px;
        height: 40px;
        padding: 5px;
    }

    @media (max-width: 768px) {
        .navbar ul {
            display: none;
            flex-direction: column;
            background: rgba(0, 0, 0, 0.9);
            position: absolute;
            top: 50px;
            right: 10px;
            text-align: left;
            padding: 10px;
            border-radius: 6px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.3);
            width: 150px;
        }

        .navbar ul.active {
            display: flex;
        }

        .menu-toggle {
            display: block;
        }
    }
</style>

    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            background: linear-gradient(135deg, #4CAF50, #2196F3);
            color: black;
            text-align: center;
        }

        .container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            width: 350px;
            text-align: center;
            transition: transform 0.3s ease-in-out;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .container:hover {
            transform: scale(1.02);
        }

        input,
        button {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
            box-sizing: border-box;
        }

        input[type="password"] {
            background-color: #f5f5f5;
        }

        button {
            font-size: large;
            font-weight: bolder;
            background: #008CBA;
            width: 150px;
            color: white;
            border: none;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
        }

        button:hover {
            background: #005f79;
            transform: scale(1.05);
        }

        .switch-container {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            margin-bottom: 15px;
            font-size: 18px;
        }

        .switch {
            position: relative;
            width: 60px;
            height: 34px;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }

        input:checked+.slider {
            background-color: #ff5733;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked+.slider:before {
            transform: translateX(26px);
        }

        .user-type {
            margin-top: 10px;
            font-size: 18px;
            font-weight: bold;
        }

        .login-fields {
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: opacity 0.5s ease-in-out, max-height 0.5s ease-in-out;
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
        }

        .show {
            opacity: 1;
            max-height: 300px;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }

        @media screen and (max-width: 400px) {
            .container {
                width: 90%;
                padding: 20px;
            }

            input {
                outline: none;
                text-align: left;
                padding-left: 10px;
                font-size: 18px;
                font-weight: bold;
            }

            button {
                font-size: 18px;
                font-weight: bold;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Select User Type</h2>
        <form method="POST">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($_GET['id'] ?? ''); ?>">
            <div class="switch-container">
                <span>Customer</span>
                <label class="switch">
                    <input type="checkbox" id="userSwitch">
                    <span class="slider"></span>
                </label>
                <span>Admin</span>
            </div>
            <input type="hidden" name="user_type" id="userType" value="customer">
            <p class="user-type">Selected: <span id="userTypeText">Customer</span></p>
            <div id="loginFields" class="login-fields">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit">Continue</button>
            <?php if (!empty($error_message)): ?>
                <p class="error"> <?php echo $error_message; ?> </p>
            <?php endif; ?>
        </form>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const userSwitch = document.getElementById('userSwitch');
            const userTypeInput = document.getElementById('userType');
            const userTypeText = document.getElementById('userTypeText');
            const loginFields = document.getElementById('loginFields');
            userSwitch.addEventListener('change', function () {
                if (this.checked) {
                    userTypeInput.value = "admin";
                    userTypeText.textContent = "Admin";
                    loginFields.style.display = "block";
                    setTimeout(() => loginFields.classList.add("show"), 10);
                } else {
                    userTypeInput.value = "customer";
                    userTypeText.textContent = "Customer";
                    loginFields.classList.remove("show");
                    setTimeout(() => loginFields.style.display = "none", 500);
                }
            });
        });
    </script>
</body>

</html>