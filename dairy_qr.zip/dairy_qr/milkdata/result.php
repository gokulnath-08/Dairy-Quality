<?php
if (isset($_GET['data'])) {
    $scannedData = htmlspecialchars($_GET['data']);
} else {
    $scannedData = 'No data found in the QR code!';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>QR Code Result</title>
    <link rel="icon" type="image/png" href="logo.png">
    <nav class="navbar">
    <div class="logo">
        <img src="logo.png" alt="Logo">
        <span style="color: white; font-size: 20px; font-weight: bold;">Dairy Quality Checker</span>
    </div>
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>
    <ul>
        <li><a id="homeLink" href="#">Home</a></li>
        <li><a href="#">Contact</a></li>
    </ul>
</nav>

<script>
const baseURL = window.location.origin;
document.getElementById("homeLink").href = baseURL;

    function toggleMenu() {
        let menu = document.querySelector('.navbar ul');
        menu.classList.toggle('active');
        
        if (menu.classList.contains('active')) {
            menu.style.display = "flex";
        } else {
            menu.style.display = "none";
        }
    }
</script>

 <style>
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #000;
            box-sizing: border-box;
            flex-wrap: wrap;
        }

        .navbar ul {
            list-style: none;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .navbar ul li {
            white-space: nowrap;
        }

        .navbar ul li a {
            text-decoration: none;
            color: white;
            font-size: 19px;
            padding: 6px 10px;
            border-radius: 4px;
            transition: background 0.3s;
        }

        .navbar ul li a:hover {
            background: rgba(255, 255, 255, 0.3);
        }



        .navbar .logo {
            display: flex;
            align-items: center;
        }

        .navbar .logo img {
            height: 30px;
            margin-right: 8px;
        }

        .navbar ul {
            list-style: none;
            display: flex;
            gap: 12px;
        }

        .navbar ul li a {
            text-decoration: none;
            color: white;
            font-size: 19px;
            padding: 6px 10px;
            border-radius: 4px;
            transition: background 0.3s;
        }

        .navbar ul li a:hover {
            background: rgba(255, 255, 255, 0.3);
        }


        .menu-toggle {
            display: none;
            font-size: 22px;
            background: none;
            border: none;
            color: white;
            cursor: pointer;
            width: 40px;
            height: 40px;
            padding: 5px;
        }

        @media (max-width: 768px) {
            .navbar ul {
                display: none;
                flex-direction: column;
                background: rgba(0, 0, 0, 0.9);
                position: absolute;
                top: 50px;
                right: 10px;
                text-align: left;
                padding: 10px;
                border-radius: 6px;
                box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.3);
                width: 150px;
            }

            .navbar ul.active {
                display: flex;
            }

            .menu-toggle {
                display: block;
            }
        }
    </style>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #4CAF50, #2196F3);
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }

        .result-box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            width: 400px;
            max-width: 90%;
            scale: 170%;
        }

        h1 {
            color: #333;
            margin-bottom: 10px;
        }

        h2 {
            color: #d32f2f;
            word-wrap: break-word;
        }
    </style>
</head>

<body>
    <div class="result-box">
        <h1>Scanned QR Code Data:</h1>
        <h2><b><?php echo $scannedData; ?></b></h2>
    </div>
</body>

</html>
