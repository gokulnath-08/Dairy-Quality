<?php
session_start();
include('db_connect.php');

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: user_selection.php");
    exit();
}

$id = $_GET['id'];
$tableName = "milkdata" . intval($id);


$stmt = $conn->prepare("SELECT ph_level, milk_quality, last_scan_time FROM $tableName ORDER BY ph_level ASC, id DESC LIMIT 1;");
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    header("Location: result.php?data=" . urlencode("Last Scan: {$row['last_scan_time']} | Quality: {$row['milk_quality']}"));
} else {
    header("Location: result.php?error=no_data_found");
}

exit();
?>