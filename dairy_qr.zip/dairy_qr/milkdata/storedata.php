<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('db_connect.php');

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Error: ID parameter is required.");
}

$id = intval($_GET['id']); 
$tableName = "milkdata" . $id; 

$createTableSQL = "CREATE TABLE IF NOT EXISTS `$tableName` (
                   id INT PRIMARY KEY AUTO_INCREMENT,
                   ph_level NUMERIC NOT NULL,
                   milk_quality VARCHAR(50) NOT NULL,
                   last_scan_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";

if (!$conn->query($createTableSQL)) {
    die("Error creating table: " . $conn->error);
}


if (isset($_GET['ph_level']) && isset($_GET['milk_quality'])) {
    $ph_level = $_GET['ph_level'];
    $milk_quality = $_GET['milk_quality'];

    echo "Received pH Level: " . htmlspecialchars($ph_level) . "<br>";
    echo "Received Milk Quality: " . htmlspecialchars($milk_quality) . "<br>";

    $stmt = $conn->prepare("INSERT INTO `$tableName` (ph_level, milk_quality) VALUES (?, ?)");
    $stmt->bind_param("ds", $ph_level, $milk_quality);

    if ($stmt->execute()) {
        echo "Data inserted successfully into table $tableName";
    } else {
        echo "Database Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Missing data! Please provide both pH level and milk quality.";
}

$conn->close();
?>