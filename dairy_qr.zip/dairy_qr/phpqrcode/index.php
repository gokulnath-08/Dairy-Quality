<?php    
    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>QR Code Generator</title>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            body {
                font-family: "Poppins", sans-serif;
                background: linear-gradient(135deg, #667eea, #764ba2);
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                padding: 20px;
            }
            .container {
                background: #fff;
                padding: 25px;
                border-radius: 12px;
                box-shadow: 0px 5px 20px rgba(0, 0, 0, 0.2);
                text-align: center;
                width: 100%;
                max-width: 400px;
            }
            h1 {
                font-size: 22px;
                font-weight: 600;
                margin-bottom: 15px;
                color: #333;
            }
            .qr-image {
                margin: 20px auto;
                display: block;
                border: 6px solid #007bff;
                padding: 12px;
                border-radius: 10px;
                width: 80%;
                max-width: 250px;
            }
            form {
                display: flex;
                flex-direction: column;
                gap: 12px;
                width: 100%;
            }
            input, select {
                padding: 12px;
                font-size: 16px;
                border: 2px solid #ccc;
                border-radius: 8px;
                outline: none;
                transition: 0.3s;
            }
            input:focus, select:focus {
                border-color: #007bff;
                box-shadow: 0px 0px 10px rgba(0, 123, 255, 0.5);
            }
            .btn {
                background: #007bff;
                color: white;
                font-size: 16px;
                font-weight: bold;
                padding: 12px;
                border: none;
                cursor: pointer;
                border-radius: 8px;
                transition: 0.3s;
            }
            .btn:hover {
                background: #0056b3;
                transform: scale(1.05);
            }
            @media (max-width: 500px) {
                .container {
                    width: 90%;
                    padding: 20px;
                }
                input, select {
                    font-size: 14px;
                    padding: 10px;
                }
                .btn {
                    font-size: 14px;
                    padding: 10px;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>QR Code Generator</h1>';

            $PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'temp'.DIRECTORY_SEPARATOR;
            $PNG_WEB_DIR = 'temp/';

            include "qrlib.php";    

            if (!file_exists($PNG_TEMP_DIR))
                mkdir($PNG_TEMP_DIR);

            $filename = $PNG_TEMP_DIR.'test.png';

            $errorCorrectionLevel = 'L';
            if (isset($_REQUEST['level']) && in_array($_REQUEST['level'], array('L','M','Q','H')))
                $errorCorrectionLevel = $_REQUEST['level'];    

            $matrixPointSize = 4;
            if (isset($_REQUEST['size']))
                $matrixPointSize = min(max((int)$_REQUEST['size'], 1), 10);

            if (isset($_REQUEST['data'])) { 
                if (trim($_REQUEST['data']) == '')
                    die('<p style="color:red;">Data cannot be empty! <a href="?">Back</a></p>');
                
                $filename = $PNG_TEMP_DIR.'test'.md5($_REQUEST['data'].'|'.$errorCorrectionLevel.'|'.$matrixPointSize).'.png';
                QRcode::png($_REQUEST['data'], $filename, $errorCorrectionLevel, $matrixPointSize, 2);    

            } else {    
                echo '<p>You can provide data in GET parameter: <a href="?data=like_that">like that</a></p>';    
                QRcode::png('PHP QR Code :)', $filename, $errorCorrectionLevel, $matrixPointSize, 2);    
            }    

            echo '<img src="'.$PNG_WEB_DIR.basename($filename).'" class="qr-image"/>';

            echo '<form action="index.php" method="post">
                <input type="text" name="data" placeholder="Enter text or URL" value="'.(isset($_REQUEST['data'])?htmlspecialchars($_REQUEST['data']):'PHP QR Code :)').'" required/>
                
                <select name="level">
                    <option value="L"'.(($errorCorrectionLevel=='L')?' selected':'').'>L - Low</option>
                    <option value="M"'.(($errorCorrectionLevel=='M')?' selected':'').'>M - Medium</option>
                    <option value="Q"'.(($errorCorrectionLevel=='Q')?' selected':'').'>Q - High</option>
                    <option value="H"'.(($errorCorrectionLevel=='H')?' selected':'').'>H - Best</option>
                </select>

                <select name="size">';
            
            for($i=1;$i<=10;$i++)
                echo '<option value="'.$i.'"'.(($matrixPointSize==$i)?' selected':'').'>Size '.$i.'</option>';
            
            echo '</select>
                <button type="submit" class="btn">Generate QR Code</button>
            </form>
        </div>
    </body>
    </html>';
?>
