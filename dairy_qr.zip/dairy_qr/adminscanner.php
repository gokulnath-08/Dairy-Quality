<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    die("Unauthorized Access");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Scanner</title>
    <link rel="icon" type="image/png" href="logo.png">
    <script src="jsQR.js"></script>
    <nav class="navbar">
        <div class="logo">
            <img src="logo.png" alt="Logo">
            <span style="color: white; font-size: 20px; font-weight: bold;">Dairy Quality Checker</span>
        </div>
        <button class="menu-toggle" onclick="toggleMenu()">☰</button>
        <ul>
            <li><a id="homeLink" href="#">Home</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </nav>
    <style>
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #000;
            box-sizing: border-box;
            flex-wrap: wrap;
        }

        .navbar ul {
            list-style: none;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .navbar ul li {
            white-space: nowrap;
        }

        .navbar ul li a {
            text-decoration: none;
            color: white;
            font-size: 19px;
            padding: 6px 10px;
            border-radius: 4px;
            transition: background 0.3s;
        }

        .navbar ul li a:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #000;
        }

        .navbar .logo {
            display: flex;
            align-items: center;
        }

        .navbar .logo img {
            height: 30px;
            margin-right: 8px;
        }

        .navbar ul {
            list-style: none;
            display: flex;
            gap: 12px;
        }

        .navbar ul li a {
            text-decoration: none;
            color: white;
            font-size: 19px;
            padding: 6px 10px;
            border-radius: 4px;
            transition: background 0.3s;
        }

        .navbar ul li a:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .menu-toggle {
            display: none;
            font-size: 22px;
            background: none;
            border: none;
            color: white;
            cursor: pointer;
            width: 40px;
            height: 40px;
            padding: 5px;
        }

        @media (max-width: 768px) {
            .navbar ul {
                display: none;
                flex-direction: column;
                background: rgba(0, 0, 0, 0.9);
                position: absolute;
                top: 50px;
                right: 10px;
                text-align: left;
                padding: 10px;
                border-radius: 6px;
                box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.3);
                width: 150px;
            }

            .navbar ul.active {
                display: flex;
            }

            .menu-toggle {
                display: block;
            }
        }
    </style>

    <script>
        const baseURL = window.location.origin;
        document.getElementById("homeLink").href = baseURL;

        function toggleMenu() {
            let menu = document.querySelector('.navbar ul');
            menu.classList.toggle('active');

            if (menu.classList.contains('active')) {
                menu.style.display = "flex";
            } else {
                menu.style.display = "none";
            }
        }
    </script>



    <style>
        body {
            font-family: 'Poppins', sans-serif;
            text-align: center;
            background: linear-gradient(135deg, #2c3e50, #4CAF50);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            background: rgba(0, 0, 0, 0.5);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            max-width: 400px;
            width: 90%;
        }

        h2 {
            font-size: 24px;
            margin: 0 0 10px;
        }

        #video {
            width: 320px;
            height: 320px;
            object-fit: cover;
            display: none;
            border: 3px solid #00c853;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }

    

        button {
            margin: 5px 0;
            padding: 12px 20px;
            font-size: 17px;
            cursor: pointer;
            font-weight: bold;
            color: white;
            background: linear-gradient(135deg, #007bff, #0056b3);
            border: none;
            border-radius: 8px;
            transition: all 0.3s ease;
            width: auto;
            max-width: 360px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            letter-spacing: 1px;
            text-align: center;
        }

        button:hover {
            background: linear-gradient(135deg, #0056b3, #004494);
            transform: scale(1.06);
        }

        #file-input {
            display: none;
        }

       
    </style>
</head>

<body>
    <div class="container">
        <h2>QR Code Scanner</h2>
        <video id="video" autoplay></video>
        <button id="scan-button">Scan QR Code with Camera</button>
        <input type="file" id="file-input" accept="image/*">
        <button id="file-input-button">Choose File</button>
        <canvas id="canvas" hidden></canvas>
    </div>
    <script>

       

        const fileInput = document.getElementById('file-input');
        const fileInputButton = document.getElementById('file-input-button');
        const scanButton = document.getElementById('scan-button');
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const ctx = canvas.getContext('2d');
        let stream;

        function handleFile(file) {
            if (file && file.type.startsWith("image/")) {
                const reader = new FileReader();
                reader.onload = function () {
                    const img = new Image();
                    img.onload = function () {
                        canvas.width = img.width;
                        canvas.height = img.height;
                        ctx.drawImage(img, 0, 0, img.width, img.height);

                        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                        const code = jsQR(imageData.data, imageData.width, imageData.height);

                        if (code) {
                            window.open(code.data, "_blank");
                        } else {
                            alert("No QR code found!");
                        }
                    };
                    img.src = reader.result;
                };
                reader.readAsDataURL(file);
            } else {
                alert("Please select a valid image file!");
            }
        }


        fileInputButton.addEventListener("click", () => {
            fileInput.click();
        });

        fileInput.addEventListener("change", (event) => {
            handleFile(event.target.files[0]);
        });

        scanButton.addEventListener("click", async () => {
            if (stream) {
                video.style.display = "none";
                scanButton.textContent = "Scan QR Code with Camera";
                stream.getTracks().forEach(track => track.stop());
                stream = null;
                return;
            }

            try {
                const constraints = {
                    video: {
                        facingMode: { ideal: "environment" },
                        width: { ideal: 300 },
                        height: { ideal: 300 }
                    }
                };
                stream = await navigator.mediaDevices.getUserMedia(constraints);
                video.srcObject = stream;
                video.style.display = "block";
                scanButton.textContent = "Stop Scanning";

                const scanQR = () => {
                    if (video.readyState === video.HAVE_ENOUGH_DATA) {
                        canvas.width = video.videoWidth;
                        canvas.height = video.videoHeight;
                        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

                        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                        const code = jsQR(imageData.data, imageData.width, imageData.height);

                        if (code) {
                            window.open(code.data, "_blank");
                            stream.getTracks().forEach(track => track.stop());
                            video.style.display = "none";
                            scanButton.textContent = "Scan QR Code with Camera";
                        } else {
                            requestAnimationFrame(scanQR);
                        }
                    } else {
                        requestAnimationFrame(scanQR);
                    }
                };
                requestAnimationFrame(scanQR);
            } catch (err) {
                alert("Camera access denied or unavailable. Please check permissions and reload the page.");
                console.error("Camera access error:", err);
            }
        });
    </script>

</body>

</html>