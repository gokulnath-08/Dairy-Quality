<?php

include('db_connect.php');

include 'phpqrcode/qrlib.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['test_no'])) {
    $test_no = htmlspecialchars($_POST['test_no']);
    $protect_qr = isset($_POST['protect_qr']) ? 1 : 0;

    $stmt = $conn->prepare("SELECT id FROM qr_store WHERE tot = ?");
    $stmt->bind_param("s", $test_no);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        header("Location: adminaccess.php?error=Sample already exists!");
        exit();
    }
    $stmt->close();

    $stmt = $conn->prepare("INSERT INTO qr_store (tot) VALUES (?)");
    $stmt->bind_param("s", $test_no);
    $stmt->execute();
    $stmt->close();

    $table_name = "milkdata{$test_no}";
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id INT PRIMARY KEY AUTO_INCREMENT,
        ph_level NUMERIC NOT NULL,
        milk_quality VARCHAR(50) NOT NULL,
        last_scan_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->query($sql);

    $base_url = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);

    if ($protect_qr) {
        $qr_data = "./milkdata/user_selection.php?id={$test_no}";
    } else {
        $qr_data = "{$base_url}/milkdata/user_selection.php?id={$test_no}";
    }


    $qr_folder = "./qr_code/";
    $qr_file = $qr_folder . "Sample-{$test_no}.png";

    if (!file_exists($qr_folder)) {
        mkdir($qr_folder, 0777, true);
    }

    QRcode::png($qr_data, $qr_file, QR_ECLEVEL_L, 10, 2);
} else {
    die("<h2 style='color: red;'>Error: Test number is missing.</h2>");
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code</title>
    <link rel="icon" type="image/jpeg" href="icon.jpeg">
    

    <style>
        body {
            text-align: center;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #4CAF50, #2196F3);
            color: white;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
            text-align: center;
            max-width: 400px;
            width: 90%;
            transition: transform 0.3s ease-in-out;
        }

        .container:hover {
            transform: scale(1.05);
        }

        h2 {
            color: #333;
            margin-bottom: 15px;
            font-size: 22px;
        }

        img {
            border: 6px solid #4CAF50;
            padding: 10px;
            border-radius: 10px;
            width: 80%;
            max-width: 250px;
            transition: transform 0.3s ease-in-out;
        }

        .cee {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 12px;
            margin-top: 20px;
        }

        a,
        button {
            display: inline-block;
            padding: 14px 20px;
            text-decoration: none;
            color: white;
            background-color: #28a745;
            border-radius: 8px;
            font-weight: bold;
            transition: all 0.3s ease-in-out;
            border: none;
            cursor: pointer;
            font-size: 14px;
        }

        a:hover,
        button:hover {
            background-color: #218838;
            transform: scale(1.12);
        }

        .return {
            margin-top: 20px;
        }

        .return a {
            background-color: #f39c12;
        }

        .return a:hover {
            background-color: #e67e22;
        }

        .loader-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 150px;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid #4CAF50;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        .hidden {
            display: none;
        }
    </style>
</head>

<body>
    <div class="container">
        <div id="loader" class="loader-container">
            <div class="spinner"></div>
        </div>

        <div id="content" class="hidden">
            <h2>QR CODE OF SAMPLE [<?php echo htmlspecialchars($test_no); ?>]</h2>
            <img src="<?php echo htmlspecialchars($qr_file); ?>"
                alt="QR Code for Sample <?php echo htmlspecialchars($test_no); ?>">

            <div class="cee">
                <a href="<?php echo htmlspecialchars($qr_file); ?>" download target="_blank">DOWNLOAD QR CODE</a>
                <a href="<?php echo htmlspecialchars($qr_data); ?>" target="_blank">OPEN LINK</a>
            </div>

            <div class="return">
                <a href="adminaccess.php">GENERATE ANOTHER QR</a>
            </div>
        </div>
    </div>

    <script>
        window.onload = function () {
            document.getElementById("loader").style.display = "none";
            document.getElementById("content").classList.remove("hidden");
        };
    </script>
</body>

</html>