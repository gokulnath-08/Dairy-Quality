<!DOCTYPE html>
<html>

<head>
    <title>Admin Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #4CAF50, #2196F3);
            color: white;
            animation: bg-animation 5s infinite alternate;
        }

        .container {
            background: white;
            color: black;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            width: 300px;
            text-align: left;
            scale: 200%;
        }


        h2 {
            text-align: center;
            color: #333;
        }

        label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 15px;
            transition: 0.3s;
        }

        input[type="submit"]:hover {
            background: #218838;
            transform: scale(1.05);
        }

        .message {
            margin-top: 10px;
            font-weight: bold;
            text-align: center;
        }

        .error {
            color: red;
        }

        .success {
            color: green;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Register Admin</h2>
        <form method="post">
            <label for="username">Username:</label>
            <input type="text" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <input type="checkbox" id="showPassword"> Show Password

            <input type="submit" value="Register">
        </form>
        <script>
            document.getElementById("showPassword").addEventListener("change", function () {
                let passwordField = document.getElementById("password");
                passwordField.type = this.checked ? "text" : "password";
            });
        </script>
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {


            include('db_connect.php');

            $user = $_POST["username"];
            $pass = $_POST["password"];

            $check_sql = "SELECT * FROM admin_users WHERE username = ?";
            $stmt = $conn->prepare($check_sql);
            $stmt->bind_param("s", $user);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                echo "<p class='message error'>Username already exists!</p>";
            } else {
                $sql = "INSERT INTO admin_users (username, password) VALUES (?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $user, $pass);

                if ($stmt->execute()) {
                    echo "<p class='message success'>Admin registered successfully!</p>";
                } else {
                    echo "<p class='message error'>Error: " . $stmt->error . "</p>";
                }
            }

            $stmt->close();
            $conn->close();
        }
        ?>
    </div>
</body>

</html>